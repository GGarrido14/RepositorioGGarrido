<?php
	session_start();

	
	if (!isset($_SESSION['formulario'])) {
		$formulario['nif'] = "";
		$formulario['nombre'] = "";
		$formulario['apellidos'] = "";		
		$formulario['fechaNacimiento'] = "";		
		$formulario['email'] = "";
		$formulario['telefono'] = "";
		$formulario['pass'] = "";
		$formulario['tipoCliente'] = "Comunidades";
	
		$_SESSION['formulario'] = $formulario;
	}
	
	else
		$formulario = $_SESSION['formulario'];
			
	
	if (isset($_SESSION["errores"]))
		$errores = $_SESSION["errores"];
?>



<!DOCTYPE html>
<html>

  <head>
    <link rel="stylesheet" href="style.css">
    <script src="script.js"></script>
     </head>
    <body>
    	
    	<?php 
		
		if (isset($errores) && count($errores)>0) { 
	    	echo "<div id=\"div_errores\" class=\"error\">";
			echo "<h4> Errores en el formulario:</h4>";
    		foreach($errores as $error) echo $error; 
    		echo "</div>";
  		}
	?>
    	
    <header><h1>Formulario para el registro de nuevos clientes</h1></header> 
    
    <form id="altaUsuario" method="get" action="accion_alta_cliente.php" novalidate>
    	
    <fieldset>
<legend align="left">
Datos personales
</legend>
	
	<label> NIF: </label>
	<input id="nif" name="NIF" type="text" placeholder="12345678X" maxlength="9" value="<?php echo $formulario['nif'];?>"
	required pattern="^[0-9]{8}[A-Z]"
	/><br>
	<label> Nombre:</label>
	<input id="nombre" name="Nombre" type="text" maxlength="30" value="<?php echo $formulario['nombre'];?>"
	required/><br>
	<label>Apellidos:</label>
	<input id="apellidos" name="Apellidos" type="text" maxlength="60" value="<?php echo $formulario['apellidos'];?>"
	required/><br>
	<label>Fecha de nacimiento</label>
	<input id="fechaNacimiento" name="Fecha de nacimiento" type="date"  value="<?php echo $formulario['fechaNacimiento'];?>"
	required/><br>
	<label>Email:</label>
	<input id="email" name="Email" type="email" 
	value="<?php echo $formulario['email'];?>" required /><br>
	<label>Telefono</label> 
	<input id="telefono" name="Telefono" type="text" 
	value="<?php echo $formulario['telefono'];?>" required pattern="[0-9]{9}"/>
	
</fieldset>
<br/>
<fieldset>
<legend align="left">
Datos de usuario
</legend>

<label>Password:</label>
<input id="pass" name="Password" type="password" min="9" placeholder="Minímo 9 caracteres entre letras y digítos" required/><br>
<label>Confirmar Password</label>
<input id="confirmpass" name="ConfirmPassword" type="password" min="9" required/><br>
<label>Tipo de trabajo:</label>
<label><input name="tipoCliente" type="radio" value="Comunidades" 
	<?php if($formulario['tipoCliente']=='Comunidades') echo ' checked ';?>	/>
	Comunidades</label>
<label><input name="tipoCliente" type="radio" value="Asesoria" 
	<?php if($formulario['tipoCliente']=='Asesoria') echo ' checked ';?> />
	Asesoría</label><br>

</fieldset><br/>
<input type="submit" value="Enviar"/>
</form>
     </body>
     
     </html>